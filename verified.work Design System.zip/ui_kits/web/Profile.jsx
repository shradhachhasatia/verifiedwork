/* ============================================================
   verified.work — Candidate profile
   Hero, ProjectGrid, EndorsementList, sidebar
   ============================================================ */

const PROFILE = {
  name: "Maya Reyes",
  handle: "mayareyes",
  title: "Backend engineer · ex-Slate, ex-Patch",
  location: "Brooklyn, NY",
  bio: "I write the boring code that keeps the lights on — payments, migrations, the parts of the system nobody wants to touch at 2am. Open to staff-level roles at small teams shipping real product.",
  endorsements: 14,
  projects: 7,
  joined: "Aug 2024",
  links: [
    { label: "mayareyes.dev", icon: "globe" },
    { label: "github.com/mayareyes", icon: "github" },
  ],
  skills: ["Postgres", "Stripe integrations", "Ruby on Rails", "Background jobs", "Migrations", "On-call"],
};

const PROJECTS = [
  { id: "p1", name: "Migration script for Slate", desc: "Zero-downtime move from MySQL to Postgres across 14 services.", endorsers: ["Jordan Vance", "Aaron Boyd", "Sana Khan"], date: "Mar 2026", swatch: "linear-gradient(135deg,#E8DCC6,#C4A878)" },
  { id: "p2", name: "Patch billing rewrite", desc: "Replaced an in-house billing system with Stripe + bespoke proration logic.", endorsers: ["Theo Marsh", "Priya Shah"], date: "Nov 2025", swatch: "linear-gradient(135deg,#C2D8CC,#6E8E7E)" },
  { id: "p3", name: "Job queue triage tool", desc: "Internal tool for inspecting and re-running failed Sidekiq jobs.", endorsers: ["Aaron Boyd"], date: "Aug 2025", swatch: "linear-gradient(135deg,#D8C8E0,#8C7AA0)" },
  { id: "p4", name: "On-call runbook", desc: "Open-source playbook for small engineering teams without a dedicated SRE.", endorsers: ["Sana Khan", "Renata Ito"], date: "Mar 2025", swatch: "linear-gradient(135deg,#BFC8DC,#6F7E96)" },
];

const ENDORSEMENTS = [
  { who: "Jordan Vance", role: "Staff Engineer · Slate", quote: "Maya wrote the migration script that saved us a weekend of downtime. Calm, careful, exact — the kind of engineer you want next to you on Friday at 6pm.", project: "Migration script for Slate", days: 2 },
  { who: "Theo Marsh", role: "Founding Eng · Patch", quote: "Mason… sorry, Maya carried the Stripe integration when half the team was on PTO. No drama. Just done.", project: "Patch billing rewrite", days: 38 },
  { who: "Sana Khan", role: "Sr. Engineer · Loom", quote: "If a refactor doesn't introduce a regression, Maya wrote it. I'd hire her again tomorrow.", project: "Migration script for Slate", days: 51 },
];

/* ---------------------------------------------------------- */

const ProfileHero = () => (
  <Section style={{ padding: "56px 0 32px" }}>
    <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 32, alignItems: "start" }}>
      <Avatar name={PROFILE.name} size={92} verified/>
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
          <h1 style={{ margin: 0, font: "700 34px/1.1 var(--vw-font-sans)", letterSpacing: "-0.02em" }}>{PROFILE.name}</h1>
          <Badge tone="verified" icon={<CheckMark size={12}/>}>Verified</Badge>
        </div>
        <div style={{ font: "400 16px/1.5 var(--vw-font-sans)", color: "var(--vw-ink-2)" }}>{PROFILE.title}</div>
        <p style={{ margin: "16px 0 0", font: "400 15px/1.6 var(--vw-font-sans)", color: "var(--vw-ink-2)", maxWidth: 580 }}>{PROFILE.bio}</p>
        <div style={{ display: "flex", gap: 8, marginTop: 18, flexWrap: "wrap" }}>
          {PROFILE.skills.map(s => <Badge key={s} tone="neutral">{s}</Badge>)}
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, alignItems: "flex-end" }}>
        <Button variant="primary" icon={<I.Message/>}>Request an intro</Button>
        <Button variant="secondary" icon={<I.Plus/>}>Endorse Maya</Button>
        <div style={{ marginTop: 8, font: "400 12px/1.4 var(--vw-font-mono)", color: "var(--vw-ink-3)", letterSpacing: "0.02em", textAlign: "right" }}>
          verified.work/{PROFILE.handle}
        </div>
      </div>
    </div>
    <div style={{
      marginTop: 36,
      display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 0,
      borderTop: "1px solid var(--vw-line)", borderBottom: "1px solid var(--vw-line)",
      padding: "20px 0",
    }}>
      <Stat label="Endorsements" value={PROFILE.endorsements} suffix="from 11 verified collaborators"/>
      <Stat label="Projects" value={PROFILE.projects} suffix="2 featured"/>
      <Stat label="On verified.work since" value={PROFILE.joined} suffix=""/>
      <Stat label="Based in" value={PROFILE.location} suffix="open to remote · NYC"/>
    </div>
  </Section>
);

const Stat = ({ label, value, suffix }) => (
  <div style={{ padding: "0 24px", borderLeft: "1px solid var(--vw-line)" }}>
    <div style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-3)", marginBottom: 8 }}>{label}</div>
    <div style={{ font: "700 22px/1.1 var(--vw-font-sans)", letterSpacing: "-0.01em", color: "var(--vw-ink)" }}>{value}</div>
    {suffix && <div style={{ font: "400 12px/1.3 var(--vw-font-sans)", color: "var(--vw-ink-3)", marginTop: 4 }}>{suffix}</div>}
  </div>
);

/* ---------------------------------------------------------- */

const ProjectGrid = ({ onOpenProject }) => (
  <Section style={{ padding: "32px 0" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", marginBottom: 20 }}>
      <h2 style={{ margin: 0, font: "700 22px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em" }}>Projects</h2>
      <div style={{ display: "flex", gap: 6 }}>
        <Button variant="ghost" size="sm">All</Button>
        <Button variant="ghost" size="sm">Endorsed</Button>
        <Button variant="ghost" size="sm">Featured</Button>
      </div>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
      {PROJECTS.map(p => <ProjectCard key={p.id} {...p} onClick={() => onOpenProject(p.id)}/>)}
    </div>
  </Section>
);

const ProjectCard = ({ name, desc, endorsers, date, swatch, onClick }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <div onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: "#fff", border: "1px solid var(--vw-line)", borderRadius: 14,
        overflow: "hidden", cursor: "pointer",
        boxShadow: hover ? "var(--vw-shadow-lg)" : "var(--vw-shadow-sm)",
        transition: "box-shadow 160ms ease, border-color 160ms ease",
        borderColor: hover ? "var(--vw-line-strong)" : "var(--vw-line)",
    }}>
      <div style={{ height: 140, background: swatch, position: "relative" }}>
        <span style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 30% 70%, rgba(255,255,255,0.32), transparent 60%)" }}></span>
      </div>
      <div style={{ padding: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <h3 style={{ margin: 0, font: "600 17px/1.2 var(--vw-font-sans)", letterSpacing: "-0.005em" }}>{name}</h3>
          <Badge tone="verified" icon={<CheckMark size={11}/>}>{endorsers.length}</Badge>
        </div>
        <p style={{ margin: "0 0 16px", font: "400 14px/1.5 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>{desc}</p>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <AvatarStack names={endorsers.slice(0, 3)} more={Math.max(0, endorsers.length - 3)} size={24}/>
          <span style={{ font: "400 12px/1 var(--vw-font-mono)", color: "var(--vw-ink-3)", letterSpacing: "0.02em" }}>{date}</span>
        </div>
      </div>
    </div>
  );
};

/* ---------------------------------------------------------- */

const EndorsementList = () => (
  <Section style={{ padding: "32px 0" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", marginBottom: 20 }}>
      <h2 style={{ margin: 0, font: "700 22px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em" }}>Recent endorsements</h2>
      <Button variant="ghost" size="sm" iconRight={<I.Arrow/>}>See all 14</Button>
    </div>
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {ENDORSEMENTS.map(e => <EndorsementCard key={e.who} {...e}/>)}
    </div>
  </Section>
);

const EndorsementCard = ({ who, role, quote, project, days }) => (
  <div style={{
    background: "#fff", border: "1px solid var(--vw-line)", borderRadius: 12,
    padding: "20px 24px", boxShadow: "var(--vw-shadow-xs)",
  }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <Avatar name={who} size={36} verified/>
        <div>
          <div style={{ font: "600 14px/1.2 var(--vw-font-sans)" }}>{who}</div>
          <div style={{ font: "400 12px/1.2 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>{role}</div>
        </div>
      </div>
      <Badge tone="verified" upper icon={<CheckMark size={11}/>}>ENDORSED</Badge>
    </div>
    <p style={{ margin: "0 0 14px", fontFamily: "var(--vw-font-serif)", fontStyle: "italic", fontSize: 18, lineHeight: 1.45, color: "var(--vw-ink)" }}>
      "{quote}"
    </p>
    <div style={{ display: "flex", gap: 12, alignItems: "center", font: "400 12px/1 var(--vw-font-mono)", color: "var(--vw-ink-3)", letterSpacing: "0.02em" }}>
      <span style={{ padding: "5px 8px", borderRadius: 4, background: "var(--vw-surface-2)" }}>on {project}</span>
      <span style={{ width: 3, height: 3, borderRadius: 999, background: "var(--vw-ink-4)" }}></span>
      <span>endorsed {days} days ago</span>
    </div>
  </div>
);

/* ---------------------------------------------------------- */

const Profile = ({ onOpenProject }) => (
  <>
    <ProfileHero/>
    <ProjectGrid onOpenProject={onOpenProject}/>
    <EndorsementList/>
  </>
);

Object.assign(window, { Profile, PROFILE, PROJECTS, ENDORSEMENTS, EndorsementCard, ProjectCard });
