/* ============================================================
   verified.work — Marketing
   Hero, HowItWorks, EndorsementShowcase, RecruiterStrip, CTA
   ============================================================ */

const Hero = ({ setScreen }) => (
  <section style={{ padding: "80px 0 56px" }}>
    <Container max={1180}>
      <div style={{ display: "grid", gridTemplateColumns: "1.05fr 1fr", gap: 80, alignItems: "center" }}>
        <div>
          <div style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.10em", textTransform: "uppercase", color: "var(--vw-ink-3)", marginBottom: 28, display: "inline-flex", alignItems: "center", gap: 10 }}>
            <CheckMark size={14}/>
            <span>For candidates &amp; the people who back them</span>
          </div>
          <MixedH size={76}>
            Your <em>work,</em><br/>endorsed by<br/>the people <em>who'd&nbsp;know.</em>
          </MixedH>
          <p style={{ marginTop: 28, font: "400 19px/1.55 var(--vw-font-sans)", color: "var(--vw-ink-2)", maxWidth: 480 }}>
            verified.work is a portfolio recruiters actually trust. Drop in a project, ask collaborators to endorse it, and let the receipts do the talking.
          </p>
          <div style={{ display: "flex", gap: 12, marginTop: 32 }}>
            <Button variant="primary" size="lg" iconRight={<I.Arrow/>} onClick={() => setScreen("profile")}>Claim your profile</Button>
            <Button variant="secondary" size="lg" onClick={() => setScreen("recruiter")}>I'm a recruiter</Button>
          </div>
          <div style={{ marginTop: 36, display: "flex", alignItems: "center", gap: 12 }}>
            <AvatarStack names={["Jordan Vance", "Sana Khan", "Diego Marsh", "Renata Ito"]} more={2} size={28}/>
            <span style={{ font: "400 13px/1.4 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>
              <b style={{ color: "var(--vw-ink)" }}>3,200+ endorsements</b> issued by verified collaborators this month
            </span>
          </div>
        </div>
        <HeroVisual setScreen={setScreen}/>
      </div>
    </Container>
  </section>
);

const HeroVisual = () => (
  <div style={{ position: "relative", height: 520 }}>
    {/* Project card — back */}
    <div style={{
      position: "absolute", top: 0, right: 0, width: 360,
      background: "#fff", border: "1px solid var(--vw-line)", borderRadius: 14,
      padding: 20, boxShadow: "var(--vw-shadow-md)",
      transform: "rotate(2deg)",
    }}>
      <div style={{ height: 132, borderRadius: 8, background: "linear-gradient(135deg,#E8DCC6,#C4A878)", marginBottom: 14, position: "relative", overflow: "hidden" }}>
        <span style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 30% 70%, rgba(255,255,255,0.4), transparent 60%)" }}></span>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ font: "600 14px/1.2 var(--vw-font-sans)", color: "var(--vw-ink)" }}>Migration script for Slate</div>
          <div style={{ font: "400 12px/1.2 var(--vw-font-sans)", color: "var(--vw-ink-3)", marginTop: 4 }}>Maya Reyes · 2 mo ago</div>
        </div>
        <Badge tone="verified" icon={<CheckMark size={12}/>}>3</Badge>
      </div>
    </div>
    {/* Endorsement card — front */}
    <div style={{
      position: "absolute", bottom: 0, left: 0, width: 400,
      background: "#fff", border: "1px solid var(--vw-line)", borderRadius: 14,
      padding: "22px 24px", boxShadow: "var(--vw-shadow-lg)",
      transform: "rotate(-2deg)",
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Avatar name="Jordan Vance" size={36} verified/>
          <div>
            <div style={{ font: "600 14px/1.2 var(--vw-font-sans)" }}>Jordan Vance</div>
            <div style={{ font: "400 12px/1.2 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>Staff Engineer · Slate</div>
          </div>
        </div>
        <Badge tone="verified" upper>ENDORSED</Badge>
      </div>
      <p style={{ margin: 0, fontFamily: "var(--vw-font-serif)", fontStyle: "italic", fontWeight: 400, fontSize: 18, lineHeight: 1.45, color: "var(--vw-ink)", letterSpacing: "-0.005em" }}>
        "Maya wrote the migration script that saved us a weekend of downtime. Calm, careful, exact."
      </p>
    </div>
    {/* Receipt — tiny */}
    <div style={{
      position: "absolute", top: 240, right: 40, width: 220,
      background: "var(--vw-ink)", color: "#fff", borderRadius: 10,
      padding: "12px 14px", boxShadow: "var(--vw-shadow-md)",
      font: "400 11px/1.7 var(--vw-font-mono)", letterSpacing: "0.02em",
      transform: "rotate(-4deg)",
    }}>
      <div style={{ color: "var(--vw-ink-4)" }}>endorsement</div>
      <div>edr_8c4a2b91f0</div>
      <div style={{ marginTop: 6, color: "var(--vw-green-tint-2)" }}>✓ verified</div>
    </div>
  </div>
);

/* ---------------------------------------------------------- */

const HowItWorks = () => {
  const steps = [
    { n: "01", t: "Show your work", d: "Add projects, links, screenshots — anything that demonstrates what you actually did." },
    { n: "02", t: "Ask for endorsements", d: "Send a one-time link to collaborators. They verify their identity, write a short take, and stamp it." },
    { n: "03", t: "Get found", d: "Recruiters search by skill and only see projects with at least one endorsement from a verified collaborator." },
  ];
  return (
    <Section eyebrow="How it works" style={{ background: "var(--vw-surface-2)", padding: "96px 0" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "start" }}>
        <h2 style={{ margin: 0, font: "700 44px/1.1 var(--vw-font-sans)", letterSpacing: "-0.02em", color: "var(--vw-ink)", maxWidth: 440 }}>
          Three steps to a portfolio<br/>recruiters trust.
        </h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 32 }}>
          {steps.map(s => (
            <div key={s.n} style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 24, alignItems: "start", paddingBottom: 28, borderBottom: "1px solid var(--vw-line)" }}>
              <span style={{ font: "500 14px/1 var(--vw-font-mono)", color: "var(--vw-ink-4)" }}>{s.n}</span>
              <div>
                <h3 style={{ margin: 0, font: "600 22px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em", color: "var(--vw-ink)" }}>{s.t}</h3>
                <p style={{ margin: "8px 0 0", font: "400 15px/1.55 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>{s.d}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
};

/* ---------------------------------------------------------- */

const EndorsementShowcase = () => {
  const items = [
    { who: "Renata Ito", role: "Founder, Halftone", quote: "Diego is the kind of designer who reads the room. He turned a vague brief into something we ended up rebuilding the brand around.", project: "Halftone rebrand", featured: true },
    { who: "Aaron Boyd", role: "EM, Loom", quote: "If a refactor doesn't introduce a regression, Sana wrote it. I'd hire her again tomorrow.", project: "Editor v3 migration" },
    { who: "Priya Shah", role: "Design Director, Linear", quote: "Quiet, thorough, opinionated in the right places. Came up with three ideas we shipped.", project: "Onboarding flow study" },
    { who: "Theo Marsh", role: "Founding Eng, Patch", quote: "Mason carried the Stripe integration when half the team was on PTO. No drama. Just done.", project: "Billing rewrite" },
  ];
  return (
    <Section eyebrow="Endorsements in the wild">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", marginBottom: 40 }}>
        <h2 style={{ margin: 0, font: "700 40px/1.1 var(--vw-font-sans)", letterSpacing: "-0.02em", maxWidth: 560 }}>
          What people actually say<br/>when they vouch for someone.
        </h2>
        <Button variant="ghost" iconRight={<I.Arrow/>}>Browse more</Button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {items.map(x => <ShowcaseCard key={x.who} {...x}/>)}
      </div>
    </Section>
  );
};

const ShowcaseCard = ({ who, role, quote, project, featured }) => (
  <div style={{
    background: featured ? "var(--vw-sand)" : "#fff",
    border: "1px solid var(--vw-line)", borderRadius: 14,
    padding: "24px 26px", boxShadow: "var(--vw-shadow-sm)",
  }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Avatar name={who} size={32} verified/>
        <div>
          <div style={{ font: "600 13px/1.2 var(--vw-font-sans)" }}>{who}</div>
          <div style={{ font: "400 12px/1.2 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>{role}</div>
        </div>
      </div>
      {featured ? <Badge tone="featured">★ Featured</Badge> : <Badge tone="verified" upper>ENDORSED</Badge>}
    </div>
    <p style={{ margin: "0 0 16px", fontFamily: "var(--vw-font-serif)", fontStyle: "italic", fontSize: 18, lineHeight: 1.45, color: "var(--vw-ink)" }}>
      "{quote}"
    </p>
    <div style={{ font: "400 12px/1 var(--vw-font-mono)", color: "var(--vw-ink-3)", letterSpacing: "0.02em" }}>
      on <span style={{ color: "var(--vw-ink)" }}>{project}</span>
    </div>
  </div>
);

/* ---------------------------------------------------------- */

const TrustStrip = () => (
  <section style={{ padding: "56px 0", borderTop: "1px solid var(--vw-line)", borderBottom: "1px solid var(--vw-line)" }}>
    <Container>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 56, alignItems: "center" }}>
        <p style={{ margin: 0, font: "500 13px/1.5 var(--vw-font-sans)", color: "var(--vw-ink-3)", letterSpacing: "0.02em" }}>
          Recruiters from teams<br/>at every stage use it.
        </p>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 24, opacity: 0.7 }}>
          {["LINEAR", "PATCH", "SLATE", "HALFTONE", "ARC", "LOOM", "FRAME"].map(n => (
            <span key={n} style={{ font: "700 18px/1 var(--vw-font-sans)", color: "var(--vw-ink-2)", letterSpacing: "0.1em" }}>{n}</span>
          ))}
        </div>
      </div>
    </Container>
  </section>
);

/* ---------------------------------------------------------- */

const CTA = ({ setScreen }) => (
  <Section style={{ padding: "112px 0" }}>
    <div style={{
      background: "var(--vw-ink)", color: "#fff",
      borderRadius: 24, padding: "72px 72px",
      display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 48, alignItems: "center",
    }}>
      <MixedH size={56} color="#fff">
        Start with one project.<br/>Get <em>one endorsement.</em>
      </MixedH>
      <div>
        <p style={{ margin: 0, font: "400 17px/1.55 var(--vw-font-sans)", color: "#D4D7D2", maxWidth: 380 }}>
          It's free to claim your profile. The hard part is asking — we make that part one click.
        </p>
        <div style={{ display: "flex", gap: 12, marginTop: 28 }}>
          <Button variant="primary" size="lg" iconRight={<I.Arrow/>} onClick={() => setScreen("profile")}>Claim your profile</Button>
          <Button size="lg" style={{ background: "transparent", color: "#fff", border: "1px solid rgba(255,255,255,0.20)" }}>See an example</Button>
        </div>
      </div>
    </div>
  </Section>
);

/* ---------------------------------------------------------- */

const Marketing = ({ setScreen }) => (
  <>
    <Hero setScreen={setScreen}/>
    <TrustStrip/>
    <HowItWorks/>
    <EndorsementShowcase/>
    <CTA setScreen={setScreen}/>
  </>
);

Object.assign(window, { Marketing });
