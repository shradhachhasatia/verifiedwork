# verified.work — Web UI Kit

A click-through recreation of the verified.work web surface. Covers:

- **Marketing home** — the landing page, mixed-type hero, how-it-works
- **Candidate profile** — someone's portfolio with endorsed projects
- **Project detail** — one project, its endorsements, the verification trail
- **Endorsement composer** — modal flow for an endorser to leave their take
- **Recruiter feed** — a recruiter browsing endorsed candidates

## Structure

```
index.html        — interactive demo (use the nav strip up top to switch screens)
App.jsx           — screen switcher
Primitives.jsx    — Button, Input, Badge, Avatar, Logo, CheckMark, Icon
Layout.jsx        — Nav, Footer, Container
Marketing.jsx     — landing page screens
Profile.jsx       — candidate profile
Project.jsx       — project detail w/ endorsements
Recruiter.jsx     — recruiter search/feed
Endorse.jsx       — endorsement composer modal
```

Open `index.html` directly — it's a single self-contained file with the CSS tokens and every JSX component inlined. The individual `*.jsx` files are kept as the readable source-of-truth for editing; if you change one, regenerate `index.html` by concatenating them into the inline `<script type="text/babel">` block (or just open the JSX file you care about directly in your own project).

## Caveats

- **No source codebase was provided** for verified.work. This UI kit is an opinionated recreation built from the brand logo + product description. Visual decisions (information architecture, microcopy, exact screen flow) are best-guess and should be confirmed.
- Lucide icons are inlined as SVG paths to keep things offline-friendly.
- Avatars use initials + a gentle gradient rather than photos.
