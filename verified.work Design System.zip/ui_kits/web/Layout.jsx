/* ============================================================
   verified.work — Layout: Nav, Footer, Container
   ============================================================ */

const Container = ({ children, max = 1180, style }) => (
  <div style={{ maxWidth: max, margin: "0 auto", padding: "0 32px", ...style }}>{children}</div>
);

const Nav = ({ screen, setScreen, signedIn = false }) => {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const link = (id, label) => {
    const active = screen === id;
    return (
      <a onClick={() => setScreen(id)} style={{
        cursor: "pointer",
        font: "500 14px/1 var(--vw-font-sans)",
        color: active ? "var(--vw-ink)" : "var(--vw-ink-3)",
        padding: "8px 12px", borderRadius: 6,
        textDecoration: "none",
      }}>{label}</a>
    );
  };
  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 50,
      background: scrolled ? "rgba(255,255,255,0.82)" : "#fff",
      backdropFilter: scrolled ? "blur(12px)" : "none",
      WebkitBackdropFilter: scrolled ? "blur(12px)" : "none",
      borderBottom: scrolled ? "1px solid var(--vw-line)" : "1px solid transparent",
      transition: "border-color 120ms, background 120ms",
    }}>
      <Container>
        <div style={{ height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
            <a onClick={() => setScreen("home")} style={{ cursor: "pointer", display: "flex", alignItems: "center" }}>
              <Logo size={20}/>
            </a>
            <nav style={{ display: "flex", gap: 4 }}>
              {link("profile", "Profiles")}
              {link("recruiter", "For recruiters")}
              <a style={{ font: "500 14px/1 var(--vw-font-sans)", color: "var(--vw-ink-3)", padding: "8px 12px" }}>Pricing</a>
              <a style={{ font: "500 14px/1 var(--vw-font-sans)", color: "var(--vw-ink-3)", padding: "8px 12px" }}>Changelog</a>
            </nav>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {!signedIn ? (
              <>
                <Button variant="ghost" size="sm">Sign in</Button>
                <Button variant="ink" size="sm">Claim your profile</Button>
              </>
            ) : (
              <>
                <Button variant="ghost" size="sm" icon={<I.Plus/>}>New project</Button>
                <Avatar name="Maya Reyes" size={32} verified/>
              </>
            )}
          </div>
        </div>
      </Container>
    </header>
  );
};

const Footer = () => (
  <footer style={{ background: "var(--vw-ink)", color: "#fff", marginTop: 96 }}>
    <Container>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr", gap: 48, padding: "64px 0" }}>
        <div>
          <Logo size={20} color="#fff"/>
          <p style={{ marginTop: 16, font: "400 14px/1.6 var(--vw-font-sans)", color: "#B4BAB6", maxWidth: 280 }}>
            Show your work. Endorsed by the people who'd know.
          </p>
        </div>
        <FooterCol title="Product" items={["For candidates", "For recruiters", "Pricing", "Changelog"]}/>
        <FooterCol title="Resources" items={["About", "Trust & verification", "Help", "Contact"]}/>
        <FooterCol title="Legal" items={["Terms", "Privacy", "Security"]}/>
      </div>
      <div style={{
        borderTop: "1px solid rgba(255,255,255,0.08)",
        padding: "20px 0",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        font: "400 12px/1 var(--vw-font-mono)", color: "var(--vw-ink-4)", letterSpacing: "0.02em",
      }}>
        <span>© 2026 verified.work</span>
        <span>made by people, endorsed by people</span>
      </div>
    </Container>
  </footer>
);

const FooterCol = ({ title, items }) => (
  <div>
    <div style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-4)", marginBottom: 14 }}>{title}</div>
    <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10 }}>
      {items.map(x => <li key={x} style={{ font: "400 14px/1 var(--vw-font-sans)", color: "#D4D7D2" }}>{x}</li>)}
    </ul>
  </div>
);

/* Section wrapper for marketing pages */
const Section = ({ eyebrow, children, style }) => (
  <section style={{ padding: "80px 0", ...style }}>
    <Container>
      {eyebrow && <div style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-3)", marginBottom: 24, display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ width: 16, height: 1, background: "var(--vw-ink-4)", display: "inline-block" }}></span>{eyebrow}
      </div>}
      {children}
    </Container>
  </section>
);

Object.assign(window, { Container, Nav, Footer, Section });
