/* ============================================================
   verified.work — Primitives
   Logo, CheckMark, Button, Input, Badge, Avatar, Icon
   ============================================================ */

const Logo = ({ size = 28, color = "var(--vw-ink)" }) => {
  const h = size;
  const w = size * 4.7;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", fontFamily: "var(--vw-font-sans)", color }}>
      <svg width={w} height={h} viewBox="0 0 560 120" aria-label="verified.work">
        <text x="0" y="86" fontFamily="Inter, sans-serif" fontWeight="800" fontSize="84" letterSpacing="-0.02em" fill={color}>verified</text>
        <g transform="translate(290, 60)">
          <circle r="16" fill="#189063"/>
          <path d="M-7 1 L-2 6.5 L8 -5" fill="none" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round"/>
        </g>
        <text x="316" y="86" fontFamily="'Source Serif 4','Source Serif Pro',Georgia,serif" fontStyle="italic" fontWeight="400" fontSize="84" letterSpacing="-0.01em" fill={color}>work</text>
      </svg>
    </span>
  );
};

const CheckMark = ({ size = 16, ring = false }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
    {ring && <circle cx="32" cy="32" r="31" fill="none" stroke="#FFFFFF" strokeWidth="2"/>}
    <circle cx="32" cy="32" r="32" fill="#189063"/>
    <path d="M18 33.2 L28 43 L46.5 23.5" fill="none" stroke="#FFFFFF" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

/* Lucide-style icon (1.5 stroke, currentColor). Pass paths via children. */
const Icon = ({ size = 16, children, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
       strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={style} aria-hidden="true">
    {children}
  </svg>
);

const I = {
  Check:    () => <Icon><path d="M20 6 9 17l-5-5"/></Icon>,
  Arrow:    () => <Icon><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></Icon>,
  Link:     () => <Icon><path d="M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 0 0-7.07-7.07l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.07 0l-3 3a5 5 0 0 0 7.07 7.07l1.5-1.5"/></Icon>,
  External: () => <Icon><path d="M7 17 17 7"/><path d="M7 7h10v10"/></Icon>,
  Plus:     () => <Icon><path d="M12 5v14"/><path d="M5 12h14"/></Icon>,
  Search:   () => <Icon><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></Icon>,
  Github:   () => <Icon><path d="M9 19c-5 1.5-5-2.5-7-3"/><path d="M15 22v-4a3.4 3.4 0 0 0-1-2.6c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.4 5.4 0 0 0 4 9c0 3.5 3 5.5 6 5.5a3.4 3.4 0 0 0-1 2.6V22"/></Icon>,
  Globe:    () => <Icon><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20"/></Icon>,
  Briefcase:()=> <Icon><path d="m21 11-1 9H4l-1-9"/><path d="M3 11h18"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></Icon>,
  User:     () => <Icon><circle cx="12" cy="8" r="4"/><path d="M4 21v-2a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v2"/></Icon>,
  Message:  () => <Icon><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></Icon>,
  Sparkle:  () => <Icon><path d="M12 3v3"/><path d="M12 18v3"/><path d="M3 12h3"/><path d="M18 12h3"/><path d="m5.6 5.6 2.1 2.1"/><path d="m16.3 16.3 2.1 2.1"/><path d="m5.6 18.4 2.1-2.1"/><path d="m16.3 7.7 2.1-2.1"/></Icon>,
  Close:    () => <Icon><path d="M18 6 6 18"/><path d="m6 6 12 12"/></Icon>,
  Filter:   () => <Icon><path d="M3 6h18"/><path d="M7 12h10"/><path d="M11 18h2"/></Icon>,
  Shield:   () => <Icon><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></Icon>,
};

/* ---------------------------------------------------------- */

const Button = ({ variant = "primary", size = "md", icon, iconRight, children, onClick, type, style, ...rest }) => {
  const base = {
    fontFamily: "var(--vw-font-sans)",
    fontWeight: 600,
    border: "1px solid transparent",
    cursor: "pointer",
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    letterSpacing: "-0.005em",
    transition: "background 120ms ease, color 120ms ease, border-color 120ms ease",
    whiteSpace: "nowrap",
  };
  const sizes = {
    sm: { padding: "7px 12px", fontSize: 13, borderRadius: 6 },
    md: { padding: "10px 16px", fontSize: 14, borderRadius: 8 },
    lg: { padding: "13px 22px", fontSize: 15, borderRadius: 10 },
  };
  const variants = {
    primary:   { background: "var(--vw-green)", color: "#fff" },
    secondary: { background: "#fff", color: "var(--vw-ink)", borderColor: "var(--vw-line-strong)" },
    ghost:     { background: "transparent", color: "var(--vw-ink)" },
    ink:       { background: "var(--vw-ink)", color: "#fff" },
    danger:    { background: "#fff", color: "var(--vw-danger)", borderColor: "var(--vw-line-strong)" },
  };
  const [hover, setHover] = React.useState(false);
  const hoverStyle = {
    primary:   { background: "var(--vw-green-deep)" },
    secondary: { borderColor: "var(--vw-ink)" },
    ghost:     { background: "var(--vw-surface-2)" },
    ink:       { background: "#000" },
    danger:    { borderColor: "var(--vw-danger)" },
  };
  return (
    <button type={type || "button"} onClick={onClick} {...rest}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ ...base, ...sizes[size], ...variants[variant], ...(hover ? hoverStyle[variant] : {}), ...style }}>
      {icon}
      {children}
      {iconRight}
    </button>
  );
};

const Input = ({ label, hint, error, value, onChange, placeholder, type = "text", style }) => {
  const [focus, setFocus] = React.useState(false);
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, ...style }}>
      {label && <span style={{ font: "500 12px/1 var(--vw-font-sans)", color: "var(--vw-ink-2)" }}>{label}</span>}
      <input type={type} value={value} onChange={onChange} placeholder={placeholder}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{
          background: "#fff",
          border: `1px solid ${error ? "var(--vw-danger)" : focus ? "var(--vw-green)" : "var(--vw-line-strong)"}`,
          boxShadow: focus && !error ? "0 0 0 3px var(--vw-green-ring)" : "none",
          borderRadius: 8, padding: "10px 12px",
          font: "400 14px/1.3 var(--vw-font-sans)",
          color: "var(--vw-ink)", outline: "none",
          transition: "border-color 120ms, box-shadow 120ms",
        }}
      />
      {(error || hint) && (
        <span style={{ font: "400 11px/1.3 var(--vw-font-sans)", color: error ? "var(--vw-danger)" : "var(--vw-ink-3)" }}>
          {error || hint}
        </span>
      )}
    </label>
  );
};

const Badge = ({ tone = "verified", upper, icon, children, style }) => {
  const tones = {
    verified: { background: "var(--vw-green-tint)", color: "var(--vw-green-darker)", border: "1px solid rgba(24,144,99,0.15)" },
    pending:  { background: "var(--vw-warning-tint)", color: "var(--vw-warning)" },
    draft:    { background: "var(--vw-surface-3)", color: "var(--vw-ink-3)" },
    info:     { background: "var(--vw-info-tint)", color: "var(--vw-info)" },
    danger:   { background: "var(--vw-danger-tint)", color: "var(--vw-danger)" },
    featured: { background: "var(--vw-sand)", color: "var(--vw-sand-ink)" },
    neutral:  { background: "var(--vw-surface-2)", color: "var(--vw-ink-2)", border: "1px solid var(--vw-line)" },
    ink:      { background: "var(--vw-ink)", color: "#fff" },
  };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      font: "500 12px/1 var(--vw-font-sans)",
      padding: upper ? "5px 8px" : "5px 10px",
      borderRadius: upper ? 4 : 999,
      letterSpacing: upper ? "0.08em" : "normal",
      textTransform: upper ? "uppercase" : "none",
      fontSize: upper ? 11 : 12,
      ...tones[tone], ...style,
    }}>{icon}{children}</span>
  );
};

/* Avatars: initials + a gentle gradient seeded by name */
function gradientFor(name) {
  const palettes = [
    ["#D4DCD8", "#A8B5AF"],
    ["#E0BFA3", "#A87C4F"],
    ["#BFC8DC", "#6F7E96"],
    ["#C2D8CC", "#6E8E7E"],
    ["#D8C8E0", "#8C7AA0"],
    ["#E8D5C2", "#B68A6E"],
  ];
  let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return palettes[h % palettes.length];
}

const Avatar = ({ name, size = 36, verified = false, style }) => {
  const parts = name.split(" ").filter(Boolean);
  const initials = (parts[0]?.[0] || "?") + (parts[1]?.[0] || "");
  const [c1, c2] = gradientFor(name);
  const badgeSize = Math.max(12, Math.round(size * 0.42));
  return (
    <span style={{ position: "relative", display: "inline-block", width: size, height: size, flexShrink: 0, ...style }}>
      <span style={{
        width: size, height: size, borderRadius: 999,
        background: `linear-gradient(135deg, ${c1}, ${c2})`,
        color: "#fff",
        fontFamily: "var(--vw-font-sans)", fontWeight: 600,
        fontSize: Math.round(size * 0.36),
        letterSpacing: "-0.01em",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
      }}>{initials.toUpperCase()}</span>
      {verified && (
        <span style={{
          position: "absolute", bottom: -2, right: -2,
          width: badgeSize, height: badgeSize, borderRadius: 999,
          background: "var(--vw-green)", border: "2px solid #fff",
          display: "inline-flex", alignItems: "center", justifyContent: "center",
        }}>
          <svg width={Math.round(badgeSize * 0.55)} height={Math.round(badgeSize * 0.55)} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
        </span>
      )}
    </span>
  );
};

const AvatarStack = ({ names, more = 0, size = 32 }) => (
  <span style={{ display: "inline-flex" }}>
    {names.map((n, i) => (
      <span key={i} style={{ marginLeft: i === 0 ? 0 : -10, border: "2px solid #fff", borderRadius: 999, display: "inline-block" }}>
        <Avatar name={n} size={size}/>
      </span>
    ))}
    {more > 0 && (
      <span style={{
        marginLeft: -10, width: size, height: size, borderRadius: 999,
        border: "2px solid #fff", background: "var(--vw-surface-3)", color: "var(--vw-ink-2)",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        font: `600 ${Math.round(size * 0.36)}px/1 var(--vw-font-sans)`,
      }}>+{more}</span>
    )}
  </span>
);

/* Mixed-type heading helper — pass children, mark italic spans with <em> */
const MixedH = ({ size = 64, children, color = "var(--vw-ink)", weight = 800, italicWeight = 400, style }) => (
  <h1 style={{
    margin: 0, fontFamily: "var(--vw-font-sans)", fontWeight: weight,
    fontSize: size, lineHeight: 1.04, letterSpacing: "-0.025em",
    color, textWrap: "balance",
    ...style,
  }}>{children}<style>{`h1 em, h2 em { font-family: var(--vw-font-serif); font-style: italic; font-weight: ${italicWeight}; letter-spacing: -0.01em; }`}</style></h1>
);

Object.assign(window, { Logo, CheckMark, Icon, I, Button, Input, Badge, Avatar, AvatarStack, MixedH, gradientFor });
