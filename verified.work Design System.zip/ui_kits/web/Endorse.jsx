/* ============================================================
   verified.work — Endorsement composer (modal)
   ============================================================ */

const EndorseModal = ({ open, onClose, onSubmit }) => {
  const [quote, setQuote] = React.useState("Maya carried us through the migration. Calm under pressure, exact under deadline.");
  const [skills, setSkills] = React.useState(["Migrations", "Postgres"]);
  const [posted, setPosted] = React.useState(false);
  if (!open) return null;

  const submit = () => {
    setPosted(true);
    setTimeout(() => { setPosted(false); onSubmit && onSubmit(); onClose(); }, 1400);
  };

  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, zIndex: 100,
      background: "rgba(15, 20, 17, 0.45)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 24,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: "min(640px, 100%)", maxHeight: "90vh", overflow: "auto",
        background: "#fff", borderRadius: 16, boxShadow: "var(--vw-shadow-xl)",
        display: "flex", flexDirection: "column",
      }}>
        <header style={{
          display: "flex", justifyContent: "space-between", alignItems: "center",
          padding: "20px 28px", borderBottom: "1px solid var(--vw-line)",
        }}>
          <div>
            <div style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-3)", marginBottom: 6 }}>Endorse · Maya Reyes</div>
            <div style={{ font: "600 18px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em" }}>Migration script for Slate</div>
          </div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", cursor: "pointer", color: "var(--vw-ink-3)", padding: 6 }}>
            <I.Close/>
          </button>
        </header>

        {posted ? (
          <SuccessState/>
        ) : (
          <div style={{ padding: "28px 28px 8px", display: "flex", flexDirection: "column", gap: 22 }}>
            <div>
              <label style={{ font: "500 12px/1 var(--vw-font-sans)", color: "var(--vw-ink-2)", display: "block", marginBottom: 8 }}>
                Your take — in your own words
              </label>
              <textarea value={quote} onChange={e => setQuote(e.target.value)} rows={4} style={{
                width: "100%", boxSizing: "border-box",
                font: "italic 400 17px/1.5 var(--vw-font-serif)",
                color: "var(--vw-ink)",
                border: "1px solid var(--vw-line-strong)", borderRadius: 10,
                padding: "14px 16px", resize: "vertical", outline: "none",
                background: "var(--vw-surface-2)",
              }}/>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
                <span style={{ font: "400 11px/1.4 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>Specific examples land better than adjectives.</span>
                <span style={{ font: "400 11px/1 var(--vw-font-mono)", color: "var(--vw-ink-4)" }}>{quote.length} / 280</span>
              </div>
            </div>

            <div>
              <label style={{ font: "500 12px/1 var(--vw-font-sans)", color: "var(--vw-ink-2)", display: "block", marginBottom: 8 }}>
                What did Maya do well?
              </label>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {["Migrations", "Postgres", "On-call", "Stripe", "Calm under pressure", "Code review", "Documentation"].map(s => {
                  const on = skills.includes(s);
                  return (
                    <button key={s} onClick={() => setSkills(on ? skills.filter(x => x !== s) : [...skills, s])} style={{
                      font: "500 13px/1 var(--vw-font-sans)",
                      padding: "8px 12px", borderRadius: 999,
                      border: `1px solid ${on ? "var(--vw-green)" : "var(--vw-line-strong)"}`,
                      background: on ? "var(--vw-green-tint)" : "#fff",
                      color: on ? "var(--vw-green-darker)" : "var(--vw-ink-2)",
                      cursor: "pointer",
                      display: "inline-flex", alignItems: "center", gap: 6,
                    }}>
                      {on && <I.Check/>}{s}
                    </button>
                  );
                })}
              </div>
            </div>

            <div style={{
              background: "var(--vw-surface-2)", border: "1px solid var(--vw-line)", borderRadius: 10,
              padding: "14px 16px",
              display: "flex", gap: 14, alignItems: "center",
            }}>
              <Avatar name="Jordan Vance" size={36} verified/>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ font: "600 13px/1.2 var(--vw-font-sans)" }}>You're endorsing as Jordan Vance</div>
                <div style={{ font: "400 12px/1.3 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>Staff Engineer · Slate · verified email on slate.io</div>
              </div>
              <Badge tone="verified" upper>VERIFIED</Badge>
            </div>
          </div>
        )}

        {!posted && (
          <footer style={{
            display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12,
            padding: "16px 28px", borderTop: "1px solid var(--vw-line)", marginTop: 18,
          }}>
            <span style={{ font: "400 12px/1.4 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>
              Endorsements are public and tied to your verified email.
            </span>
            <div style={{ display: "flex", gap: 8 }}>
              <Button variant="ghost" onClick={onClose}>Cancel</Button>
              <Button variant="primary" onClick={submit} icon={<CheckMark size={14}/>}>Publish endorsement</Button>
            </div>
          </footer>
        )}
      </div>
    </div>
  );
};

const SuccessState = () => (
  <div style={{ padding: "56px 28px", textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
    <div style={{ animation: "stamp 380ms cubic-bezier(.2,1.3,.4,1)" }}>
      <CheckMark size={64}/>
    </div>
    <div style={{ font: "700 22px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em" }}>Endorsement published.</div>
    <div style={{ font: "400 14px/1.5 var(--vw-font-sans)", color: "var(--vw-ink-3)", maxWidth: 380 }}>
      Maya will be notified. Recruiters viewing this project will see your name and role.
    </div>
    <style>{`@keyframes stamp { 0% { transform: scale(0.6); opacity: 0; } 60% { transform: scale(1.08); opacity: 1; } 100% { transform: scale(1); } }`}</style>
  </div>
);

Object.assign(window, { EndorseModal });
