/* ============================================================
   verified.work — Recruiter feed
   Sidebar filters, candidate cards with verified endorsements
   ============================================================ */

const CANDIDATES = [
  { id: "c1", name: "Maya Reyes", title: "Backend engineer · ex-Slate, ex-Patch", location: "Brooklyn, NY", skills: ["Postgres", "Stripe", "Migrations"], endorsements: 14, top: "Jordan Vance · Staff Eng, Slate", quote: "Calm, careful, exact — the kind of engineer you want next to you on Friday at 6pm.", featured: true },
  { id: "c2", name: "Diego Marsh", title: "Brand designer · Halftone, ex-Frame", location: "Mexico City", skills: ["Brand", "Identity", "Type"], endorsements: 9, top: "Renata Ito · Founder, Halftone", quote: "Reads the room. Turned a vague brief into something we ended up rebuilding the brand around." },
  { id: "c3", name: "Sana Khan", title: "Sr. engineer · Loom", location: "London", skills: ["TypeScript", "Refactors", "Editor"], endorsements: 11, top: "Aaron Boyd · EM, Loom", quote: "If a refactor doesn't introduce a regression, Sana wrote it. I'd hire her again tomorrow." },
  { id: "c4", name: "Mason Liu", title: "Full-stack · Patch", location: "Austin, TX", skills: ["Stripe", "Billing", "Rails"], endorsements: 7, top: "Theo Marsh · Founding Eng, Patch", quote: "Carried the Stripe integration when half the team was on PTO. No drama. Just done." },
];

const Recruiter = ({ setScreen }) => {
  const [filter, setFilter] = React.useState("All");
  return (
    <Container>
      <div style={{ padding: "32px 0 8px" }}>
        <div style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-3)", marginBottom: 12 }}>For recruiters</div>
        <h1 style={{ margin: 0, font: "700 32px/1.15 var(--vw-font-sans)", letterSpacing: "-0.02em" }}>
          Candidates with at least one verified endorsement.
        </h1>
        <p style={{ margin: "12px 0 0", font: "400 16px/1.55 var(--vw-font-sans)", color: "var(--vw-ink-3)", maxWidth: 640 }}>
          Every project here has been vouched for by a verified collaborator. No self-claims.
        </p>
      </div>

      <div style={{ marginTop: 28, display: "flex", gap: 12, alignItems: "center" }}>
        <SearchField/>
        <Button variant="secondary" icon={<I.Filter/>}>Filters</Button>
      </div>

      <div style={{ marginTop: 16, display: "flex", gap: 8, flexWrap: "wrap" }}>
        {["All", "Engineering", "Design", "Product", "Founding", "Open to remote"].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            font: "500 13px/1 var(--vw-font-sans)",
            padding: "8px 14px", borderRadius: 999,
            background: filter === f ? "var(--vw-ink)" : "#fff",
            color: filter === f ? "#fff" : "var(--vw-ink-2)",
            border: `1px solid ${filter === f ? "var(--vw-ink)" : "var(--vw-line-strong)"}`,
            cursor: "pointer",
          }}>{f}</button>
        ))}
      </div>

      <div style={{ marginTop: 32, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {CANDIDATES.map(c => <CandidateCard key={c.id} {...c} onOpen={() => setScreen("profile")}/>)}
      </div>
    </Container>
  );
};

const SearchField = () => {
  const [v, setV] = React.useState("postgres migrations");
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      flex: 1,
      background: "#fff",
      border: `1px solid ${focus ? "var(--vw-green)" : "var(--vw-line-strong)"}`,
      boxShadow: focus ? "0 0 0 3px var(--vw-green-ring)" : "none",
      borderRadius: 10, padding: "10px 14px",
      transition: "border-color 120ms, box-shadow 120ms",
    }}>
      <span style={{ color: "var(--vw-ink-3)" }}><I.Search size={18}/></span>
      <input value={v} onChange={e => setV(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        placeholder="Search by skill, role, or project…"
        style={{ flex: 1, border: "none", outline: "none", background: "transparent", font: "400 15px/1 var(--vw-font-sans)", color: "var(--vw-ink)" }}/>
      <span style={{ font: "400 11px/1 var(--vw-font-mono)", color: "var(--vw-ink-4)", padding: "4px 6px", border: "1px solid var(--vw-line)", borderRadius: 4 }}>⌘ K</span>
    </div>
  );
};

const CandidateCard = ({ name, title, location, skills, endorsements, top, quote, featured, onOpen }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <div onClick={onOpen} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{
      background: featured ? "var(--vw-sand)" : "#fff",
      border: "1px solid var(--vw-line)", borderRadius: 14,
      padding: 22, cursor: "pointer",
      boxShadow: hover ? "var(--vw-shadow-md)" : "var(--vw-shadow-sm)",
      transition: "box-shadow 160ms",
    }}>
      <div style={{ display: "flex", gap: 14, alignItems: "flex-start", marginBottom: 14 }}>
        <Avatar name={name} size={48} verified/>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <h3 style={{ margin: 0, font: "600 17px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em" }}>{name}</h3>
            {featured && <Badge tone="featured">★ Featured</Badge>}
          </div>
          <div style={{ font: "400 13px/1.4 var(--vw-font-sans)", color: "var(--vw-ink-3)", marginTop: 2 }}>{title}</div>
          <div style={{ font: "400 12px/1 var(--vw-font-sans)", color: "var(--vw-ink-4)", marginTop: 6 }}>{location}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ font: "700 20px/1 var(--vw-font-sans)", color: "var(--vw-green-darker)" }}>{endorsements}</div>
          <div style={{ font: "500 10px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-3)", marginTop: 4 }}>endorsements</div>
        </div>
      </div>

      <p style={{ margin: "0 0 12px", fontFamily: "var(--vw-font-serif)", fontStyle: "italic", fontSize: 15, lineHeight: 1.5, color: "var(--vw-ink)" }}>
        "{quote}"
      </p>
      <div style={{ font: "400 12px/1.3 var(--vw-font-mono)", color: "var(--vw-ink-3)", letterSpacing: "0.02em", marginBottom: 14 }}>
        — {top}
      </div>

      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
        {skills.map(s => <Badge key={s} tone="neutral">{s}</Badge>)}
      </div>
    </div>
  );
};

Object.assign(window, { Recruiter });
