/* ============================================================
   verified.work — Project detail
   Hero, gallery, endorsements rail, verification receipt
   ============================================================ */

const ProjectDetail = ({ projectId, setScreen, openEndorse }) => {
  const project = PROJECTS.find(p => p.id === projectId) || PROJECTS[0];
  const endorsements = ENDORSEMENTS.filter(e => e.project === project.name);
  return (
    <>
      <Container>
        <div style={{ padding: "32px 0 16px", font: "400 13px/1 var(--vw-font-sans)", color: "var(--vw-ink-3)", display: "flex", gap: 8, alignItems: "center" }}>
          <a onClick={() => setScreen("profile")} style={{ cursor: "pointer", color: "var(--vw-ink-3)" }}>{PROFILE.name}</a>
          <span>/</span>
          <span style={{ color: "var(--vw-ink)" }}>{project.name}</span>
        </div>
      </Container>

      <Container>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 56, alignItems: "start", paddingBottom: 32 }}>
          <div>
            <h1 style={{ margin: "0 0 12px", font: "700 38px/1.1 var(--vw-font-sans)", letterSpacing: "-0.02em", maxWidth: 640 }}>
              {project.name}
            </h1>
            <p style={{ margin: 0, font: "400 18px/1.55 var(--vw-font-sans)", color: "var(--vw-ink-2)", maxWidth: 640 }}>{project.desc}</p>
            <div style={{ display: "flex", gap: 8, marginTop: 20, flexWrap: "wrap" }}>
              <Badge tone="neutral" icon={<I.Briefcase/>}>Slate · 2026</Badge>
              <Badge tone="neutral">Postgres</Badge>
              <Badge tone="neutral">MySQL → Postgres</Badge>
              <Badge tone="neutral">Zero-downtime</Badge>
            </div>

            <div style={{
              marginTop: 32, height: 360, borderRadius: 16, background: project.swatch,
              position: "relative", overflow: "hidden",
              boxShadow: "var(--vw-shadow-md)",
            }}>
              <span style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 30% 70%, rgba(255,255,255,0.32), transparent 60%)" }}></span>
              <span style={{
                position: "absolute", bottom: 20, left: 24,
                font: "500 11px/1 var(--vw-font-mono)", color: "rgba(255,255,255,0.85)",
                letterSpacing: "0.08em", textTransform: "uppercase",
              }}>Cover</span>
            </div>

            <article style={{ marginTop: 40, maxWidth: 640 }}>
              <h2 style={{ margin: "0 0 12px", font: "600 22px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em" }}>
                What I did
              </h2>
              <p style={{ font: "400 16px/1.7 var(--vw-font-sans)", color: "var(--vw-ink-2)" }}>
                Slate had a 9-year-old MySQL database that everything ran on. We needed to move to Postgres without an outage window. I wrote the dual-write layer, the verification harness, and the cutover script — and ran point on the night-of migration.
              </p>
              <h2 style={{ margin: "32px 0 12px", font: "600 22px/1.2 var(--vw-font-sans)", letterSpacing: "-0.01em" }}>
                What it took
              </h2>
              <ul style={{ font: "400 16px/1.8 var(--vw-font-sans)", color: "var(--vw-ink-2)", paddingLeft: 20 }}>
                <li>Six weeks of dual-write traffic in production</li>
                <li>A bespoke diff tool to catch silent inconsistencies</li>
                <li>One pager at 3am that turned out to be a typo</li>
              </ul>
              <blockquote style={{
                margin: "32px 0 0", padding: "20px 28px",
                background: "var(--vw-sand)", borderRadius: 12,
                fontFamily: "var(--vw-font-serif)", fontStyle: "italic", fontSize: 19, lineHeight: 1.45,
                color: "var(--vw-ink)",
              }}>
                "Calm, careful, exact — the kind of engineer you want next to you on Friday at 6pm."
                <div style={{ marginTop: 12, font: "500 13px/1 var(--vw-font-sans)", color: "var(--vw-sand-ink)", fontStyle: "normal" }}>
                  Jordan Vance, Staff Engineer at Slate
                </div>
              </blockquote>
            </article>
          </div>

          <aside style={{ position: "sticky", top: 88 }}>
            <ReceiptCard project={project} endorsements={endorsements.length || 3} openEndorse={openEndorse}/>
            <EndorsersList endorsements={endorsements.length ? endorsements : ENDORSEMENTS.slice(0, 2)}/>
          </aside>
        </div>
      </Container>
    </>
  );
};

const ReceiptCard = ({ project, endorsements, openEndorse }) => (
  <div style={{
    background: "var(--vw-ink)", color: "#fff",
    borderRadius: 14, padding: "20px 22px",
    fontFamily: "var(--vw-font-mono)", fontSize: 12, lineHeight: 1.9,
    letterSpacing: "0.02em",
    boxShadow: "var(--vw-shadow-md)",
  }}>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
      <span style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-4)" }}>Verification receipt</span>
      <CheckMark size={18}/>
    </div>
    <div><span style={{ color: "var(--vw-ink-4)" }}>project</span>  prj_a14f8c</div>
    <div><span style={{ color: "var(--vw-ink-4)" }}>author</span>   maya@reyes.dev</div>
    <div><span style={{ color: "var(--vw-ink-4)" }}>endors.</span>  {endorsements} verified</div>
    <div><span style={{ color: "var(--vw-ink-4)" }}>status</span>   <span style={{ color: "var(--vw-green-tint-2)" }}>✓ verified</span></div>
    <Button variant="primary" size="sm" style={{ width: "100%", justifyContent: "center", marginTop: 14 }} onClick={openEndorse}>
      Endorse this project
    </Button>
  </div>
);

const EndorsersList = ({ endorsements }) => (
  <div style={{ marginTop: 20 }}>
    <div style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-3)", marginBottom: 14 }}>Endorsed by</div>
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {endorsements.map(e => (
        <div key={e.who} style={{
          display: "flex", gap: 12, padding: "12px 14px",
          background: "#fff", border: "1px solid var(--vw-line)", borderRadius: 10,
        }}>
          <Avatar name={e.who} size={32} verified/>
          <div style={{ minWidth: 0 }}>
            <div style={{ font: "600 13px/1.2 var(--vw-font-sans)" }}>{e.who}</div>
            <div style={{ font: "400 12px/1.3 var(--vw-font-sans)", color: "var(--vw-ink-3)" }}>{e.role}</div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

Object.assign(window, { ProjectDetail });
