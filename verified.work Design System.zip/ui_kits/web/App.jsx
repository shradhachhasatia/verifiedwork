/* ============================================================
   verified.work — App shell + screen switcher
   ============================================================ */

const ScreenSwitcher = ({ screen, setScreen }) => {
  const items = [
    { id: "home", label: "Marketing home" },
    { id: "profile", label: "Profile" },
    { id: "project", label: "Project detail" },
    { id: "recruiter", label: "Recruiter feed" },
  ];
  return (
    <div style={{
      position: "fixed", bottom: 20, left: "50%", transform: "translateX(-50%)",
      zIndex: 200,
      background: "var(--vw-ink)", color: "#fff",
      borderRadius: 999, padding: 4,
      display: "flex", gap: 2, alignItems: "center",
      boxShadow: "var(--vw-shadow-lg)",
      font: "500 13px/1 var(--vw-font-sans)",
    }}>
      <span style={{ font: "500 11px/1 var(--vw-font-sans)", letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--vw-ink-4)", padding: "0 14px 0 16px" }}>DEMO</span>
      {items.map(it => {
        const active = screen === it.id || (it.id === "project" && screen.startsWith("project"));
        return (
          <button key={it.id} onClick={() => setScreen(it.id === "project" ? "project:p1" : it.id)} style={{
            background: active ? "#fff" : "transparent",
            color: active ? "var(--vw-ink)" : "#fff",
            border: "none", padding: "8px 14px", borderRadius: 999,
            cursor: "pointer", font: "inherit",
          }}>{it.label}</button>
        );
      })}
    </div>
  );
};

const App = () => {
  const [screen, setScreen] = React.useState("home");
  const [endorseOpen, setEndorseOpen] = React.useState(false);

  React.useEffect(() => { window.scrollTo(0, 0); }, [screen]);

  const signedIn = screen !== "home";

  const openProject = (id) => setScreen("project:" + id);
  const renderScreen = () => {
    if (screen === "home")      return <Marketing setScreen={setScreen}/>;
    if (screen === "profile")   return <Profile onOpenProject={openProject}/>;
    if (screen.startsWith("project")) {
      const id = screen.split(":")[1] || "p1";
      return <ProjectDetail projectId={id} setScreen={setScreen} openEndorse={() => setEndorseOpen(true)}/>;
    }
    if (screen === "recruiter") return <Recruiter setScreen={setScreen}/>;
    return null;
  };

  const baseScreen = screen.startsWith("project") ? "profile" : screen;

  return (
    <div>
      <Nav screen={baseScreen} setScreen={setScreen} signedIn={signedIn}/>
      <main>{renderScreen()}</main>
      <Footer/>
      <EndorseModal open={endorseOpen} onClose={() => setEndorseOpen(false)}/>
      <ScreenSwitcher screen={screen} setScreen={setScreen}/>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
