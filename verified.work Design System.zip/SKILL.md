---
name: verifiedwork-design
description: Use this skill to generate well-branded interfaces and assets for VerifiedWork — landing pages, product UI, slide decks, prototypes, social cards, badges, illustrations. Contains the brand's spec-locked color tokens (green + black + white + grey), Inter-only type system with bold/regular weight contrast, voice rules, the V/W app icon, the verification badge, and a click-through web UI kit.
user-invocable: true
---

# VerifiedWork — design skill

Read `README.md` first. It covers the brand premise, locked colors, type, voice, and visual foundations. Then skim the other files.

## What's here

- `README.md` — full system reference
- `colors_and_type.css` — CSS variables (tokens) + semantic type styles
- `assets/` — wordmarks (3 contexts), V/W icon (3 contexts), verification check dot
- `preview/` — single-purpose preview cards (logo, icon, badges, colors, type, components)
- `ui_kits/web/` — click-through React UI kit (note: built on the earlier brand direction; tokens have been migrated but it still uses some pre-pivot type treatments — see README caveats)

## Spec-locked values

| | |
|---|---|
| Primary green | `#2D6A4F` |
| Secondary green | `#40916C` (only used inside the V/W mark and for soft accents) |
| Light green tint | `#D8F3DC` |
| Black | `#1A1A1A` |
| White | `#FFFFFF` |
| Grey | `#6B7280` (the word "work", captions, secondary text) |
| Type | **Inter only** — Bold (700) + Regular (400) is the contrast |
| Icons | Lucide, 1.5 stroke |

## The three brand-defining moves

1. **Wordmark lockup** — `verified` (Inter Bold #1A1A1A) · green check dot · `work` (Inter Regular #6B7280). On black: white + light grey + green dot. On green: white + 70%-white + white dot with green check.
2. **V/W app icon** — bold white V with a green W-tail that rises into a checkmark, on a 22%-rounded black square. The V and the green tail share a top-middle vertex so they feel like one unified letterform.
3. **Verification badge** — green pill, white check + "VerifiedWork" in Inter Medium. Two sizes (24px, 48px) + a square stamp version (white with green border).

## Rules of thumb

- White is the canvas. The brand never has gradient or textured backgrounds.
- The green is a stamp, not a paint bucket. Two or three uses per screen, max.
- Inter only. Bold + Regular contrast is the rhythm.
- No emoji. No serif. No italic for emphasis. No blue. Ever.
- The icon never floats on a colored background other than the three approved versions (black / white / green).

## If invoked with no other guidance

Ask the user what they want to build — a landing variant, a profile card, a badge for LinkedIn, a slide, a social tile, a feature mock, a flow prototype. Ask one or two clarifying questions. Then build it as HTML, lifting from the tokens and assets here.
