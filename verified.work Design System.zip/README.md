# VerifiedWork — Design System

A design system for **VerifiedWork** — a verified professional profile platform built around intent-based hiring. Users showcase what they've actually done; collaborators who were there verify it; recruiters search only candidates with verified evidence.

> Human validation in an AI world.

---

## Brand premise

VerifiedWork is the antidote to AI-generated everything. The brand has to feel **human, warm, and credible** without slipping into corporate or cold. The reference points are the credibility of Stripe, the humanness of Notion, the confidence of Linear — but distinctly its own.

The wordmark expresses this in two weights of one typeface:

- **verified** — Inter Bold, **#1A1A1A**. The strong claim.
- **·** — green check dot (white check inside #2D6A4F disc). The verification stamp.
- **work** — Inter Regular, **#6B7280**. The human context.

The contrast between bold and regular is intentional. Don't make "work" the same weight as "verified."

## Sources

- `uploads/IMG_0068.jpeg` — the original logo lockup (early concept)
- `uploads/IMG_0070.jpeg` — the **locked** wordmark direction (verified bold black · green check · work regular grey)
- `uploads/IMG_0071.jpeg` — the **locked** standalone icon direction (bold white V + green W-tail checkmark on black rounded square)
- Brand brief — Gen Z professionals · students · interns · freelancers · global; intent-based hiring; built on human verification

---

## Index

```
README.md                       — this file
SKILL.md                        — agent skill entry-point
colors_and_type.css             — CSS variables: tokens + semantic type
assets/
  logo-primary.svg              — wordmark, on white  (vector reference; needs Inter)
  logo-primary-on-black.svg     — wordmark, on black
  logo-primary-on-green.svg     — wordmark, on green
  logo-icon.svg                 — V/W app icon on black (canonical)
  logo-icon-white.svg           — V/W app icon on white
  logo-icon-green.svg           — V/W app icon on green
  logo-mark.svg                 — standalone verification check dot
preview/                        — Design System tab cards
ui_kits/web/                    — click-through web product UI kit
```

---

## Brand colors — spec-locked

| Token | Hex | Use |
|---|---|---|
| `--vw-green` | **#2D6A4F** | primary CTAs, the verification stamp, badges |
| `--vw-green-2` | **#40916C** | secondary accents, the W tail in the app icon |
| `--vw-green-tint` | **#D8F3DC** | success surfaces, gentle highlights |
| `--vw-black` | **#1A1A1A** | primary text, dark surfaces, app icon background |
| `--vw-white` | **#FFFFFF** | canvas |
| `--vw-grey` | **#6B7280** | the word "work", secondary text, captions |

The green check is the **only color accent**. No other colors. No blue.

## Typography — Inter only

- `verified` — **Inter Bold (700)**, `#1A1A1A`
- `work` — **Inter Regular (400)**, `#6B7280`
- UI body / headings / labels — Inter, weight scale 400 / 500 / 600 / 700 / 800
- `JetBrains Mono` only for receipts, IDs, timestamps

No serif. No italics for emphasis. The bold-regular weight contrast IS the rhythm.

---

## Content fundamentals

### Voice

- **Human and warm, not corporate.** Speak like a colleague.
- **Confident, declarative.** "Human validation in an AI world." Not "We help validate humans with AI."
- **For young professionals, not HR departments.** No "talent pipeline" energy.
- **Trustworthy but approachable.** Don't sound like a bank.

### Casing

- Wordmark is **always lowercase**: `verified` · `work` (never "VerifiedWork" except in the badge text and product-name contexts).
- **Sentence case** for headlines, page titles, buttons.
- **UPPER · TRACKED 0.08em** only for tiny eyebrows and tags ("VERIFIED", "ENDORSED").

### Tone examples

| Context | ✅ | ❌ |
|---|---|---|
| Marketing hero | "Human validation in an AI world." | "AI-powered career validation platform" |
| Empty state | "No endorsements yet. Share your project to get the first one." | "Oops! Nothing here yet 🤷" |
| Success | "Endorsement published." | "🎉 You did it!" |
| CTA | "Get verified" / "Endorse this" | "Get Started" / "Click Here" |
| Error | "That email doesn't look right." | "Invalid email address" |

### Punctuation

- Periods on full sentences. **No periods on buttons** or short labels.
- Em-dashes — like this — preferred over parentheses.
- **No emoji.** The green check dot is the only "icon-emoji" the brand uses.

---

## Visual foundations

### Color

The brand is **green + black + white + grey**. That's it. The green is the verification stamp — treat it as rare and intentional, never decorative. Anti-pattern: green buttons, green section headers, green dividers, green underlines all on the same screen. Pick one place per view.

### Type

Inter only. The signature move is bold/regular contrast in headlines. No mixed-serif lockups. Headlines can use the same trick as the wordmark — a bold phrase and a regular continuation in grey — to carry the brand rhythm into long-form copy.

### Spacing

4pt grid: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 80 / 96.

### Backgrounds, imagery, texture

- **No textures, patterns, gradients.** White or off-white.
- **No stock photography.** If you need imagery, use the user's project work — never generic team-around-a-laptop.
- **No full-bleed marketing imagery** behind text. Imagery sits in a card; text sits on white.

### Animation

- Restrained, 150–220ms `ease-out`.
- Signature animation: **the stamp** — when something becomes verified, the check scales 0.6 → 1.08 → 1.0 over 280ms.
- No bounce. No parallax. No ambient looping motion.

### States

| State | Treatment |
|---|---|
| Hover (primary button) | Bg → `--vw-green-deep` (#1F4A37) |
| Hover (secondary) | Border → black |
| Hover (card) | shadow-sm → shadow-md, no translate |
| Press | scale 0.98, 80ms |
| Focus | 3px green ring (rgba 22%) |
| Disabled | grey-2 (#9CA3AF), surface-2, not-allowed |

### Borders, radii, shadows

- **Hairlines** — 1px `--vw-line` (#E5E7EB) almost everywhere.
- Radii: **10px** default (cards/inputs), **6px** for chips, **pill** for status, **20–28px** only on hero cards, **22% width** for app icon corners.
- Shadows: paper-like, low-opacity. Never colored.

### Cards

White, 1px `--vw-line`, 10–14px radius, `--vw-shadow-sm` rest → `--vw-shadow-md` hover. Padding 20–24px.

### Layout

Max content width **1180px**; reading column **640–720px**. 64px sticky top nav, white with hairline border on scroll.

### Transparency & blur

Used in **one place**: the sticky nav becomes `rgba(255,255,255,0.82)` + `backdrop-filter: blur(12px)` when content scrolls under it. Nowhere else. No frosted glass.

---

## Iconography

- **Lucide**, 1.5px stroke, rounded caps/joins. Linked from CDN.
- **No emoji** in product or marketing. The green check dot is the only "icon-emoji" the brand uses.
- **No icon fonts.** Inline SVG so `currentColor` tints work.

> ⚠️ **Icon set substitution flag.** No bespoke icon set was provided. Lucide is the neutral default; happy to swap for Phosphor, Tabler, or a custom set on request.

### Sizes

12 / 14 / 16 / 20 / 24 px. UI icons 16px; nav 20px; section headers 24px.

### The V/W app icon

The standalone mark used as favicon, app icon, profile badge, and social profile picture. Bold white V, green W-tail with checkmark, on a 22%-rounded black square. Works from 16px to 1024px. Variants: on black (canonical), on white, on green, transparent context.

### The verification check

The dot inside the wordmark, the badge glyph, the toast icon — all the same green disc + white check. Use `assets/logo-mark.svg`.

---

## How to use this system

1. Import `colors_and_type.css` and use CSS variables — never hard-code hex.
2. Use only Inter. Lean on the bold/regular weight contrast.
3. The green is a stamp, not paint. Two-three usages per screen, max.
4. Pull real Lucide SVGs. Don't draw your own check marks.
5. Use the V/W icon for square contexts (avatar, favicon, app icon). Use the wordmark for headers and lockups.
6. Reference `ui_kits/web/` for ready-made components.

---

## Caveats / open questions

1. The earlier preview cards (radii, shadows, components-buttons, etc.) were built under a previous brand direction (sans+serif duality, different greens). They've been re-tokened to the new system and render correctly, but a few — type-mono, type-editorial, components-endorsement — may still feel slightly off-brand. Re-do these if you want them on-spec.
2. **The web UI kit (`ui_kits/web/`)** was built under the previous brand direction. It still works and renders, but it uses serif italic for quotes — which the new spec disallows. **Recommend rebuilding the UI kit on the new tokens** once we agree on the surfaces (candidate dashboard, recruiter side, etc.).
3. Some social/marketing deliverables from your spec aren't here yet: LinkedIn banner (1584×396), social profile picture (400×400), the email signature lockup. Easy follow-ups once we lock the icon.
